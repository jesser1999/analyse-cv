import { hash } from "bcrypt";

// Fonction pour créer un nouvel utilisateur
export async function createUser(
  db: any,
  email: string,
  password: string,
  name: string
) {
  // Vérifier si l'utilisateur existe déjà
  const existingUser = await db
    .prepare("SELECT id FROM users WHERE email = ?")
    .bind(email)
    .first();

  if (existingUser) {
    throw new Error("Cet email est déjà utilisé");
  }

  // Hacher le mot de passe
  const hashedPassword = await hash(password, 10);

  // Insérer le nouvel utilisateur
  const result = await db
    .prepare(
      "INSERT INTO users (email, password_hash, name) VALUES (?, ?, ?) RETURNING id"
    )
    .bind(email, hashedPassword, name)
    .first();

  return {
    id: result.id.toString(),
    email,
    name,
  };
}

// Fonction pour récupérer un utilisateur par son ID
export async function getUserById(db: any, id: string) {
  const user = await db
    .prepare("SELECT id, email, name FROM users WHERE id = ?")
    .bind(id)
    .first();

  if (!user) {
    return null;
  }

  return {
    id: user.id.toString(),
    email: user.email,
    name: user.name,
  };
}

// Fonction pour récupérer un utilisateur par son email
export async function getUserByEmail(db: any, email: string) {
  const user = await db
    .prepare("SELECT id, email, name FROM users WHERE email = ?")
    .bind(email)
    .first();

  if (!user) {
    return null;
  }

  return {
    id: user.id.toString(),
    email: user.email,
    name: user.name,
  };
}
