import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { CVScorer } from "@/lib/cv-scorer";

// Fonction pour noter un CV analysé
export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    // Vérifier l'authentification
    // @ts-ignore - La session sera disponible dans le contexte de l'API
    const session = await getServerSession();
    if (!session || !session.user) {
      return NextResponse.json(
        { message: "Non autorisé" },
        { status: 401 }
      );
    }

    // Récupérer l'ID de l'utilisateur
    const userId = session.user.id;
    const cvId = params.id;
    
    if (!cvId) {
      return NextResponse.json(
        { message: "ID de CV manquant" },
        { status: 400 }
      );
    }
    
    // @ts-ignore - DB sera disponible dans le contexte de l'API
    const db = request.env?.DB;
    
    if (!db) {
      return NextResponse.json(
        { message: "Erreur de connexion à la base de données" },
        { status: 500 }
      );
    }
    
    // Récupérer l'analyse du CV
    const analysis = await db
      .prepare(
        "SELECT a.id, a.cv_id, a.analysis_data, c.user_id FROM analysis a JOIN cvs c ON a.cv_id = c.id WHERE a.cv_id = ?"
      )
      .bind(cvId)
      .first();
    
    if (!analysis) {
      return NextResponse.json(
        { message: "Analyse non trouvée" },
        { status: 404 }
      );
    }
    
    // Vérifier que le CV appartient à l'utilisateur
    if (analysis.user_id !== userId) {
      return NextResponse.json(
        { message: "Non autorisé à accéder à cette analyse" },
        { status: 403 }
      );
    }
    
    // Analyser les données JSON
    const analysisData = JSON.parse(analysis.analysis_data);
    
    // Calculer le score avec l'algorithme de notation
    const scoringResult = CVScorer.calculateScore(analysisData);
    
    // Mettre à jour le score total dans la base de données
    await db
      .prepare(
        "UPDATE analysis SET total_score = ? WHERE id = ?"
      )
      .bind(scoringResult.totalScore, analysis.id)
      .run();
    
    // Enregistrer les scores par catégorie
    for (const [category, data] of Object.entries(scoringResult.categoryScores)) {
      // Récupérer l'ID de la catégorie
      const categoryRecord = await db
        .prepare("SELECT id FROM analysis_categories WHERE name LIKE ?")
        .bind(`%${category}%`)
        .first();
      
      if (categoryRecord) {
        // Vérifier si un résultat existe déjà pour cette analyse et cette catégorie
        const existingResult = await db
          .prepare("SELECT id FROM analysis_results WHERE analysis_id = ? AND category_id = ?")
          .bind(analysis.id, categoryRecord.id)
          .first();
        
        if (existingResult) {
          // Mettre à jour le résultat existant
          await db
            .prepare("UPDATE analysis_results SET score = ? WHERE id = ?")
            .bind(data.score, existingResult.id)
            .run();
        } else {
          // Créer un nouveau résultat
          await db
            .prepare(
              "INSERT INTO analysis_results (analysis_id, category_id, score) VALUES (?, ?, ?)"
            )
            .bind(analysis.id, categoryRecord.id, data.score)
            .run();
        }
      }
    }
    
    return NextResponse.json(
      {
        message: "Notation du CV effectuée avec succès",
        scoring: scoringResult
      },
      { status: 200 }
    );
  } catch (error) {
    console.error("Erreur lors de la notation du CV:", error);
    return NextResponse.json(
      { message: "Une erreur est survenue lors de la notation du CV" },
      { status: 500 }
    );
  }
}
