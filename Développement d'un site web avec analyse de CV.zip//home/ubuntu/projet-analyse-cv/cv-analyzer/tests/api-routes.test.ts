import { describe, it, expect, beforeEach, vi, afterEach } from 'vitest';
import { NextRequest, NextResponse } from 'next/server';

// Mock des modules et fonctions
vi.mock('next-auth', () => ({
  getServerSession: vi.fn().mockResolvedValue({
    user: { id: '1', name: 'Test User', email: 'test@example.com' }
  })
}));

vi.mock('fs/promises', () => ({
  writeFile: vi.fn().mockResolvedValue(undefined),
  mkdir: vi.fn().mockResolvedValue(undefined)
}));

vi.mock('fs', () => ({
  existsSync: vi.fn().mockReturnValue(true)
}));

// Mock de l'API route handler
const mockRequest = {
  formData: vi.fn(),
  env: {
    DB: {
      prepare: vi.fn().mockReturnThis(),
      bind: vi.fn().mockReturnThis(),
      first: vi.fn(),
      all: vi.fn(),
      run: vi.fn()
    }
  }
} as unknown as NextRequest;

// Reset des mocks après chaque test
afterEach(() => {
  vi.clearAllMocks();
});

describe('API Routes', () => {
  describe('Upload API', () => {
    it('devrait rejeter les requêtes non authentifiées', async () => {
      // Remplacer le mock de getServerSession pour ce test
      const getServerSession = require('next-auth').getServerSession;
      getServerSession.mockResolvedValueOnce(null);
      
      // Importer la route d'API
      const { POST } = await import('../src/app/api/cv/upload/route');
      
      // Appeler la route
      const response = await POST(mockRequest);
      
      // Vérifier la réponse
      expect(response.status).toBe(401);
      const data = await response.json();
      expect(data.message).toBe('Non autorisé');
    });
    
    it('devrait valider le type de fichier', async () => {
      // Mock de formData avec un fichier invalide
      mockRequest.formData.mockResolvedValueOnce({
        get: () => ({
          type: 'text/plain',
          size: 1024,
          name: 'test.txt',
          arrayBuffer: vi.fn().mockResolvedValue(new ArrayBuffer(1024))
        })
      });
      
      // Importer la route d'API
      const { POST } = await import('../src/app/api/cv/upload/route');
      
      // Appeler la route
      const response = await POST(mockRequest);
      
      // Vérifier la réponse
      expect(response.status).toBe(400);
      const data = await response.json();
      expect(data.message).toContain('Format de fichier non supporté');
    });
    
    it('devrait valider la taille du fichier', async () => {
      // Mock de formData avec un fichier trop volumineux
      mockRequest.formData.mockResolvedValueOnce({
        get: () => ({
          type: 'application/pdf',
          size: 10 * 1024 * 1024, // 10MB
          name: 'test.pdf',
          arrayBuffer: vi.fn().mockResolvedValue(new ArrayBuffer(10 * 1024 * 1024))
        })
      });
      
      // Importer la route d'API
      const { POST } = await import('../src/app/api/cv/upload/route');
      
      // Appeler la route
      const response = await POST(mockRequest);
      
      // Vérifier la réponse
      expect(response.status).toBe(400);
      const data = await response.json();
      expect(data.message).toContain('trop volumineux');
    });
    
    it('devrait accepter un fichier PDF valide', async () => {
      // Mock de formData avec un fichier PDF valide
      mockRequest.formData.mockResolvedValueOnce({
        get: () => ({
          type: 'application/pdf',
          size: 1024 * 1024, // 1MB
          name: 'test.pdf',
          arrayBuffer: vi.fn().mockResolvedValue(new ArrayBuffer(1024 * 1024))
        })
      });
      
      // Mock de la base de données pour retourner un ID
      mockRequest.env.DB.prepare().bind().first.mockResolvedValueOnce({ id: 1 });
      
      // Importer la route d'API
      const { POST } = await import('../src/app/api/cv/upload/route');
      
      // Appeler la route
      const response = await POST(mockRequest);
      
      // Vérifier la réponse
      expect(response.status).toBe(201);
      const data = await response.json();
      expect(data.message).toContain('CV téléchargé avec succès');
      expect(data.cvId).toBe(1);
    });
  });
  
  describe('Analyze API', () => {
    it('devrait rejeter les requêtes pour des CV inexistants', async () => {
      // Mock de la base de données pour retourner null
      mockRequest.env.DB.prepare().bind().first.mockResolvedValueOnce(null);
      
      // Importer la route d'API
      const { GET } = await import('../src/app/api/cv/analyze/[id]/route');
      
      // Appeler la route
      const response = await GET(mockRequest, { params: { id: '999' } });
      
      // Vérifier la réponse
      expect(response.status).toBe(404);
      const data = await response.json();
      expect(data.message).toBe('CV non trouvé');
    });
    
    it('devrait rejeter les requêtes pour des CV appartenant à d\'autres utilisateurs', async () => {
      // Mock de la base de données pour retourner un CV d'un autre utilisateur
      mockRequest.env.DB.prepare().bind().first.mockResolvedValueOnce({
        id: 1,
        user_id: '2', // Différent de l'ID de l'utilisateur connecté
        file_name: 'test.pdf',
        file_path: '/path/to/test.pdf',
        file_type: 'application/pdf'
      });
      
      // Importer la route d'API
      const { GET } = await import('../src/app/api/cv/analyze/[id]/route');
      
      // Appeler la route
      const response = await GET(mockRequest, { params: { id: '1' } });
      
      // Vérifier la réponse
      expect(response.status).toBe(403);
      const data = await response.json();
      expect(data.message).toContain('Non autorisé');
    });
  });
  
  describe('Score API', () => {
    it('devrait calculer et enregistrer le score d\'un CV', async () => {
      // Mock de la base de données pour retourner une analyse
      mockRequest.env.DB.prepare().bind().first
        .mockResolvedValueOnce({
          id: 1,
          cv_id: 1,
          user_id: '1', // Même ID que l'utilisateur connecté
          analysis_data: JSON.stringify({
            education: [{ degree: 'Master', institution: 'Université' }],
            experience: [{ title: 'Développeur', company: 'Entreprise' }],
            skills: ['javascript', 'react'],
            languages: [{ language: 'français', level: 'natif' }],
            projects: [{ name: 'Projet', url: 'https://github.com' }]
          })
        })
        // Mock pour la catégorie
        .mockResolvedValueOnce({ id: 1 });
      
      // Importer la route d'API
      const { GET } = await import('../src/app/api/cv/score/[id]/route');
      
      // Appeler la route
      const response = await GET(mockRequest, { params: { id: '1' } });
      
      // Vérifier la réponse
      expect(response.status).toBe(200);
      const data = await response.json();
      expect(data.message).toContain('Notation du CV effectuée avec succès');
      expect(data.scoring).toHaveProperty('totalScore');
      expect(data.scoring).toHaveProperty('classification');
      
      // Vérifier que la mise à jour du score a été appelée
      expect(mockRequest.env.DB.prepare).toHaveBeenCalledWith(
        expect.stringContaining('UPDATE analysis SET total_score')
      );
    });
  });
});
