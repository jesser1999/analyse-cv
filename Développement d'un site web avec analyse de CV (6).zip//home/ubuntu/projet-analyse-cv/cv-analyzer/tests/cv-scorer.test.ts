import { describe, it, expect, beforeEach, vi } from 'vitest';
import { CVScorer } from '../src/lib/cv-scorer';

describe('CVScorer', () => {
  describe('calculateScore', () => {
    it('devrait calculer correctement le score global d\'un CV complet', () => {
      const mockAnalysis = {
        education: [
          { degree: 'Master', institution: 'Université de Paris', period: '2018-2020' },
          { degree: 'Licence', institution: 'Université de Lyon', period: '2015-2018' }
        ],
        experience: [
          { title: 'Développeur Full Stack', company: 'Entreprise XYZ', period: '2020-2023', description: 'Développement d\'applications web avec React et Node.js' },
          { title: 'Développeur Frontend', company: 'Startup ABC', period: '2018-2020', description: 'Création d\'interfaces utilisateur avec HTML, CSS et JavaScript' }
        ],
        skills: ['javascript', 'react', 'node.js', 'html', 'css', 'python', 'git', 'docker'],
        languages: [
          { language: 'français', level: 'natif' },
          { language: 'anglais', level: 'courant' },
          { language: 'espagnol', level: 'intermédiaire' }
        ],
        projects: [
          { name: 'Application de gestion', url: 'https://github.com/user/project', period: '2021-2023', description: 'Développement d\'une application web avec React et Firebase' }
        ]
      };
      
      const result = CVScorer.calculateScore(mockAnalysis);
      
      // Vérifier que le résultat contient toutes les propriétés attendues
      expect(result).toHaveProperty('totalScore');
      expect(result).toHaveProperty('categoryScores');
      expect(result).toHaveProperty('classification');
      
      // Vérifier que les scores par catégorie sont présents
      expect(result.categoryScores).toHaveProperty('education');
      expect(result.categoryScores).toHaveProperty('experience');
      expect(result.categoryScores).toHaveProperty('skills');
      expect(result.categoryScores).toHaveProperty('languages');
      expect(result.categoryScores).toHaveProperty('projects');
      
      // Vérifier que le score total est un nombre entre 0 et 100
      expect(result.totalScore).toBeGreaterThanOrEqual(0);
      expect(result.totalScore).toBeLessThanOrEqual(100);
      
      // Vérifier que la classification est une des valeurs attendues
      expect(['Excellent', 'Bon', 'Moyen', 'Passable', 'Insuffisant']).toContain(result.classification);
    });
    
    it('devrait attribuer un score faible à un CV vide', () => {
      const emptyAnalysis = {
        education: [],
        experience: [],
        skills: [],
        languages: [],
        projects: []
      };
      
      const result = CVScorer.calculateScore(emptyAnalysis);
      
      // Vérifier que le score total est 0
      expect(result.totalScore).toBe(0);
      
      // Vérifier que la classification est "Insuffisant"
      expect(result.classification).toBe('Insuffisant');
      
      // Vérifier que tous les scores par catégorie sont à 0
      Object.values(result.categoryScores).forEach(categoryScore => {
        expect(categoryScore.score).toBe(0);
      });
    });
    
    it('devrait attribuer un score partiel à un CV incomplet', () => {
      const partialAnalysis = {
        education: [],
        experience: [
          { title: 'Développeur', company: 'Entreprise XYZ', period: '2020-2023', description: 'Développement d\'applications' }
        ],
        skills: ['javascript', 'html', 'css'],
        languages: [],
        projects: []
      };
      
      const result = CVScorer.calculateScore(partialAnalysis);
      
      // Vérifier que le score total est supérieur à 0 mais inférieur à 50
      expect(result.totalScore).toBeGreaterThan(0);
      expect(result.totalScore).toBeLessThan(50);
      
      // Vérifier que certains scores par catégorie sont supérieurs à 0
      expect(result.categoryScores.experience.score).toBeGreaterThan(0);
      expect(result.categoryScores.skills.score).toBeGreaterThan(0);
      
      // Vérifier que d'autres scores par catégorie sont à 0
      expect(result.categoryScores.education.score).toBe(0);
      expect(result.categoryScores.languages.score).toBe(0);
      expect(result.categoryScores.projects.score).toBe(0);
    });
  });
});
