"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";

interface AnalysisData {
  education: any[];
  experience: any[];
  skills: string[];
  languages: any[];
  projects: any[];
  raw_text: string;
}

interface Analysis {
  analysisId: number;
  analysis: AnalysisData;
}

export default function AnalysisDetailPage({
  params,
}: {
  params: { id: string };
}) {
  const router = useRouter();
  const [analysis, setAnalysis] = useState<Analysis | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    const fetchAnalysis = async () => {
      try {
        setLoading(true);
        const response = await fetch(`/api/cv/analyze/${params.id}`);

        if (!response.ok) {
          throw new Error("Erreur lors de l'analyse du CV");
        }

        const data = await response.json();
        setAnalysis(data);
      } catch (error: any) {
        setError(error.message || "Une erreur est survenue");
      } finally {
        setLoading(false);
      }
    };

    fetchAnalysis();
  }, [params.id]);

  if (loading) {
    return (
      <div className="px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex flex-col items-center justify-center py-12">
          <svg
            className="animate-spin h-12 w-12 text-blue-600 mb-4"
            xmlns="http://www.w3.org/2000/svg"
            fill="none"
            viewBox="0 0 24 24"
          >
            <circle
              className="opacity-25"
              cx="12"
              cy="12"
              r="10"
              stroke="currentColor"
              strokeWidth="4"
            ></circle>
            <path
              className="opacity-75"
              fill="currentColor"
              d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
            ></path>
          </svg>
          <h3 className="text-lg font-medium text-gray-900">
            Analyse du CV en cours...
          </h3>
          <p className="mt-1 text-sm text-gray-500">
            Veuillez patienter pendant que nous analysons votre CV.
          </p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="px-4 sm:px-6 lg:px-8 py-8">
        <div className="bg-red-50 border-l-4 border-red-400 p-4 mb-6">
          <div className="flex">
            <div className="flex-shrink-0">
              <svg
                className="h-5 w-5 text-red-400"
                xmlns="http://www.w3.org/2000/svg"
                viewBox="0 0 20 20"
                fill="currentColor"
              >
                <path
                  fillRule="evenodd"
                  d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z"
                  clipRule="evenodd"
                />
              </svg>
            </div>
            <div className="ml-3">
              <p className="text-sm text-red-700">{error}</p>
            </div>
          </div>
        </div>
        <div className="flex justify-center">
          <Link
            href="/dashboard/analysis"
            className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
          >
            Retour aux analyses
          </Link>
        </div>
      </div>
    );
  }

  if (!analysis) {
    return (
      <div className="px-4 sm:px-6 lg:px-8 py-8">
        <div className="bg-yellow-50 border-l-4 border-yellow-400 p-4 mb-6">
          <div className="flex">
            <div className="flex-shrink-0">
              <svg
                className="h-5 w-5 text-yellow-400"
                xmlns="http://www.w3.org/2000/svg"
                viewBox="0 0 20 20"
                fill="currentColor"
              >
                <path
                  fillRule="evenodd"
                  d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z"
                  clipRule="evenodd"
                />
              </svg>
            </div>
            <div className="ml-3">
              <p className="text-sm text-yellow-700">
                Aucune analyse disponible pour ce CV.
              </p>
            </div>
          </div>
        </div>
        <div className="flex justify-center">
          <Link
            href="/dashboard/analysis"
            className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
          >
            Retour aux analyses
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="px-4 sm:px-6 lg:px-8 py-6">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-semibold text-gray-900">
          Analyse du CV
        </h1>
        <Link
          href="/dashboard/analysis"
          className="inline-flex items-center px-4 py-2 border border-gray-300 shadow-sm text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
        >
          Retour aux analyses
        </Link>
      </div>

      <div className="bg-white shadow overflow-hidden sm:rounded-lg mb-6">
        <div className="px-4 py-5 sm:px-6">
          <h3 className="text-lg leading-6 font-medium text-gray-900">
            Résumé de l'analyse
          </h3>
          <p className="mt-1 max-w-2xl text-sm text-gray-500">
            Aperçu des éléments extraits de votre CV.
          </p>
        </div>
        <div className="border-t border-gray-200 px-4 py-5 sm:p-0">
          <dl className="sm:divide-y sm:divide-gray-200">
            <div className="py-4 sm:py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
              <dt className="text-sm font-medium text-gray-500">Formation et éducation</dt>
              <dd className="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">
                {analysis.analysis.education.length > 0 ? (
                  <ul className="divide-y divide-gray-200">
                    {analysis.analysis.education.map((edu, index) => (
                      <li key={index} className="py-2">
                        <div className="font-medium">{edu.degree}</div>
                        <div>{edu.institution}</div>
                        <div className="text-sm text-gray-500">{edu.period}</div>
                      </li>
                    ))}
                  </ul>
                ) : (
                  <span className="text-gray-500 italic">Aucune formation détectée</span>
                )}
              </dd>
            </div>
            <div className="py-4 sm:py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
              <dt className="text-sm font-medium text-gray-500">Expérience professionnelle</dt>
              <dd className="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">
                {analysis.analysis.experience.length > 0 ? (
                  <ul className="divide-y divide-gray-200">
                    {analysis.analysis.experience.map((exp, index) => (
                      <li key={index} className="py-2">
                        <div className="font-medium">{exp.title}</div>
                        <div>{exp.company}</div>
                        <div className="text-sm text-gray-500">{exp.period}</div>
                      </li>
                    ))}
                  </ul>
                ) : (
                  <span className="text-gray-500 italic">Aucune expérience détectée</span>
                )}
              </dd>
            </div>
            <div className="py-4 sm:py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
              <dt className="text-sm font-medium text-gray-500">Compétences techniques</dt>
              <dd className="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">
                {analysis.analysis.skills.length > 0 ? (
                  <div className="flex flex-wrap gap-2">
                    {analysis.analysis.skills.map((skill, index) => (
                      <span
                        key={index}
                        className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800"
                      >
                        {skill}
                      </span>
                    ))}
                  </div>
                ) : (
                  <span className="text-gray-500 italic">Aucune compétence détectée</span>
                )}
              </dd>
            </div>
            <div className="py-4 sm:py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
              <dt className="text-sm font-medium text-gray-500">Langues</dt>
              <dd className="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">
                {analysis.analysis.languages.length > 0 ? (
                  <ul className="divide-y divide-gray-200">
                    {analysis.analysis.languages.map((lang, index) => (
                      <li key={index} className="py-2">
                        <div className="font-medium">{lang.language}</div>
                        <div className="text-sm text-gray-500">{lang.level}</div>
                      </li>
                    ))}
                  </ul>
                ) : (
                  <span className="text-gray-500 italic">Aucune langue détectée</span>
                )}
              </dd>
            </div>
            <div className="py-4 sm:py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
              <dt className="text-sm font-medium text-gray-500">Projets personnels</dt>
              <dd className="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">
                {analysis.analysis.projects.length > 0 ? (
                  <ul className="divide-y divide-gray-200">
                    {analysis.analysis.projects.map((project, index) => (
                      <li key={index} className="py-2">
                        <div className="font-medium">{project.name}</div>
                        {project.url && (
                          <div>
                            <a
                              href={project.url}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="text-blue-600 hover:text-blue-800"
                            >
                              {project.url}
                            </a>
                          </div>
                        )}
                        <div className="text-sm text-gray-500">{project.period}</div>
                      </li>
                    ))}
                  </ul>
                ) : (
                  <span className="text-gray-500 italic">Aucun projet détecté</span>
                )}
              </dd>
            </div>
          </dl>
        </div>
      </div>

      <div className="bg-white shadow overflow-hidden sm:rounded-lg">
        <div className="px-4 py-5 sm:px-6">
          <h3 className="text-lg leading-6 font-medium text-gray-900">
            Prochaines étapes
          </h3>
          <p className="mt-1 max-w-2xl text-sm text-gray-500">
            Votre CV a été analysé avec succès. Vous pouvez maintenant procéder à l'évaluation.
          </p>
        </div>
        <div className="border-t border-gray-200 px-4 py-5 sm:px-6">
          <div className="flex justify-end">
            <Link
              href={`/dashboard/analysis/${params.id}/score`}
              className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
            >
              Évaluer ce CV
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
