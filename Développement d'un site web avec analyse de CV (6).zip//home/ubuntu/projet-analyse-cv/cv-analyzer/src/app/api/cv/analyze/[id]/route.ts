import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { join } from "path";
import { CVAnalyzer } from "@/lib/cv-analyzer";

// Fonction pour analyser un CV
export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    // Vérifier l'authentification
    // @ts-ignore - La session sera disponible dans le contexte de l'API
    const session = await getServerSession();
    if (!session || !session.user) {
      return NextResponse.json(
        { message: "Non autorisé" },
        { status: 401 }
      );
    }

    // Récupérer l'ID de l'utilisateur
    const userId = session.user.id;
    const cvId = params.id;
    
    if (!cvId) {
      return NextResponse.json(
        { message: "ID de CV manquant" },
        { status: 400 }
      );
    }
    
    // @ts-ignore - DB sera disponible dans le contexte de l'API
    const db = request.env?.DB;
    
    if (!db) {
      return NextResponse.json(
        { message: "Erreur de connexion à la base de données" },
        { status: 500 }
      );
    }
    
    // Récupérer les informations du CV
    const cv = await db
      .prepare(
        "SELECT id, user_id, file_name, file_path, file_type FROM cvs WHERE id = ?"
      )
      .bind(cvId)
      .first();
    
    if (!cv) {
      return NextResponse.json(
        { message: "CV non trouvé" },
        { status: 404 }
      );
    }
    
    // Vérifier que le CV appartient à l'utilisateur
    if (cv.user_id !== userId) {
      return NextResponse.json(
        { message: "Non autorisé à accéder à ce CV" },
        { status: 403 }
      );
    }
    
    // Extraire le texte du CV
    const text = await CVAnalyzer.extractText(cv.file_path, cv.file_type);
    
    // Analyser le contenu du CV
    const analysis = CVAnalyzer.analyzeCV(text);
    
    // Vérifier si une analyse existe déjà pour ce CV
    const existingAnalysis = await db
      .prepare("SELECT id FROM analysis WHERE cv_id = ?")
      .bind(cvId)
      .first();
    
    let analysisId;
    
    if (existingAnalysis) {
      // Mettre à jour l'analyse existante
      await db
        .prepare(
          "UPDATE analysis SET analysis_data = ?, analysis_date = CURRENT_TIMESTAMP WHERE id = ?"
        )
        .bind(JSON.stringify(analysis), existingAnalysis.id)
        .run();
      
      analysisId = existingAnalysis.id;
    } else {
      // Créer une nouvelle analyse
      // Pour l'instant, on met un score total temporaire de 0
      // Il sera calculé dans l'étape suivante (scoring)
      const result = await db
        .prepare(
          "INSERT INTO analysis (cv_id, total_score, analysis_data) VALUES (?, 0, ?) RETURNING id"
        )
        .bind(cvId, JSON.stringify(analysis))
        .first();
      
      analysisId = result.id;
    }
    
    return NextResponse.json(
      {
        message: "Analyse du CV effectuée avec succès",
        analysisId,
        analysis
      },
      { status: 200 }
    );
  } catch (error) {
    console.error("Erreur lors de l'analyse du CV:", error);
    return NextResponse.json(
      { message: "Une erreur est survenue lors de l'analyse du CV" },
      { status: 500 }
    );
  }
}
