# Préparation du déploiement

Ce fichier contient les instructions pour préparer l'application CV Analyzer au déploiement.

## Vérification pré-déploiement

Avant de déployer l'application, assurez-vous que :

1. Toutes les fonctionnalités sont implémentées et testées
2. Les variables d'environnement sont correctement configurées
3. Les dépendances sont à jour
4. Les tests unitaires passent avec succès

## Configuration pour le déploiement

Pour déployer cette application, nous utiliserons la fonctionnalité de déploiement intégrée qui permet de déployer gratuitement des applications Next.js.

### Étapes de déploiement

1. Vérifier que le projet est correctement configuré pour le déploiement
2. Créer un build de production
3. Déployer l'application
4. Vérifier le bon fonctionnement en production

### Variables d'environnement requises

Les variables d'environnement suivantes doivent être configurées dans l'environnement de production :

- `NEXTAUTH_SECRET`: Clé secrète pour NextAuth.js
- `NEXTAUTH_URL`: URL de base de l'application déployée

### Dossiers à exclure du déploiement

- `node_modules/`
- `.wrangler/`
- `.git/`
- `tests/`
