import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { join } from "path";
import { writeFile, mkdir } from "fs/promises";
import { existsSync } from "fs";

// Fonction pour gérer le téléchargement de CV
export async function POST(request: NextRequest) {
  try {
    // Vérifier l'authentification
    // @ts-ignore - La session sera disponible dans le contexte de l'API
    const session = await getServerSession();
    if (!session || !session.user) {
      return NextResponse.json(
        { message: "Non autorisé" },
        { status: 401 }
      );
    }

    // Récupérer l'ID de l'utilisateur
    const userId = session.user.id;

    // Récupérer le fichier depuis la requête
    const formData = await request.formData();
    const file = formData.get("file") as File;

    if (!file) {
      return NextResponse.json(
        { message: "Aucun fichier n'a été fourni" },
        { status: 400 }
      );
    }

    // Vérifier le type de fichier
    const allowedTypes = ["application/pdf", "application/vnd.openxmlformats-officedocument.wordprocessingml.document"];
    if (!allowedTypes.includes(file.type)) {
      return NextResponse.json(
        { message: "Format de fichier non supporté. Veuillez télécharger un fichier PDF ou DOCX." },
        { status: 400 }
      );
    }

    // Vérifier la taille du fichier (max 5MB)
    if (file.size > 5 * 1024 * 1024) {
      return NextResponse.json(
        { message: "Le fichier est trop volumineux. La taille maximale est de 5MB." },
        { status: 400 }
      );
    }

    // Créer un nom de fichier unique
    const fileExtension = file.type === "application/pdf" ? ".pdf" : ".docx";
    const fileName = `${Date.now()}_${file.name.replace(/\s+/g, "_")}`;
    
    // Créer le répertoire de stockage s'il n'existe pas
    const uploadDir = join(process.cwd(), "uploads", userId);
    if (!existsSync(uploadDir)) {
      await mkdir(uploadDir, { recursive: true });
    }
    
    // Chemin complet du fichier
    const filePath = join(uploadDir, fileName);
    
    // Écrire le fichier sur le disque
    const fileBuffer = await file.arrayBuffer();
    await writeFile(filePath, Buffer.from(fileBuffer));
    
    // @ts-ignore - DB sera disponible dans le contexte de l'API
    const db = request.env?.DB;
    
    if (!db) {
      return NextResponse.json(
        { message: "Erreur de connexion à la base de données" },
        { status: 500 }
      );
    }
    
    // Enregistrer les informations du CV dans la base de données
    const result = await db
      .prepare(
        "INSERT INTO cvs (user_id, file_name, file_path, file_type, file_size) VALUES (?, ?, ?, ?, ?) RETURNING id"
      )
      .bind(userId, fileName, filePath, file.type, file.size)
      .first();
    
    // Retourner l'ID du CV pour redirection vers l'analyse
    return NextResponse.json(
      {
        message: "CV téléchargé avec succès",
        cvId: result.id,
        fileName: fileName
      },
      { status: 201 }
    );
  } catch (error) {
    console.error("Erreur lors du téléchargement du CV:", error);
    return NextResponse.json(
      { message: "Une erreur est survenue lors du téléchargement du CV" },
      { status: 500 }
    );
  }
}
