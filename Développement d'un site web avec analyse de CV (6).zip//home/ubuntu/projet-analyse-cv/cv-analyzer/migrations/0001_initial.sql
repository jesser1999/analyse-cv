-- Migration number: 0001 	 2025-01-16T13:42:41.031Z
DROP TABLE IF EXISTS counters;
DROP TABLE IF EXISTS access_logs;
DROP TABLE IF EXISTS users;
DROP TABLE IF EXISTS cvs;
DROP TABLE IF EXISTS analysis;
DROP TABLE IF EXISTS analysis_categories;
DROP TABLE IF EXISTS analysis_results;

-- Table pour les compteurs et logs d'accès
CREATE TABLE IF NOT EXISTS counters (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT UNIQUE NOT NULL,
  value INTEGER NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS access_logs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  ip TEXT,
  path TEXT,
  accessed_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Table des utilisateurs pour l'authentification
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  email TEXT UNIQUE NOT NULL,
  password_hash TEXT,
  name TEXT NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Table pour stocker les informations des CV
CREATE TABLE IF NOT EXISTS cvs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  file_name TEXT NOT NULL,
  file_path TEXT NOT NULL,
  file_type TEXT NOT NULL,
  upload_date DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  file_size INTEGER NOT NULL,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Table pour stocker les analyses de CV
CREATE TABLE IF NOT EXISTS analysis (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  cv_id INTEGER NOT NULL,
  analysis_date DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  total_score REAL NOT NULL,
  analysis_data TEXT NOT NULL, -- JSON format
  FOREIGN KEY (cv_id) REFERENCES cvs(id) ON DELETE CASCADE
);

-- Table pour les catégories d'analyse
CREATE TABLE IF NOT EXISTS analysis_categories (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  description TEXT NOT NULL,
  weight REAL NOT NULL
);

-- Table pour les résultats d'analyse par catégorie
CREATE TABLE IF NOT EXISTS analysis_results (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  analysis_id INTEGER NOT NULL,
  category_id INTEGER NOT NULL,
  score REAL NOT NULL,
  extracted_content TEXT,
  comments TEXT,
  FOREIGN KEY (analysis_id) REFERENCES analysis(id) ON DELETE CASCADE,
  FOREIGN KEY (category_id) REFERENCES analysis_categories(id) ON DELETE CASCADE
);

-- Données initiales
INSERT INTO counters (name, value) VALUES 
  ('page_views', 0),
  ('api_calls', 0);

-- Catégories d'analyse prédéfinies
INSERT INTO analysis_categories (name, description, weight) VALUES
  ('Formation et éducation', 'Diplômes, établissements et formations complémentaires', 0.20),
  ('Expérience professionnelle', 'Postes, durée, responsabilités et réalisations', 0.30),
  ('Compétences techniques', 'Langages, outils, technologies et certifications', 0.25),
  ('Langues', 'Langues maîtrisées et niveau de compétence', 0.10),
  ('Projets personnels', 'Projets open source, publications et conférences', 0.15);

-- Création des index
CREATE INDEX idx_access_logs_accessed_at ON access_logs(accessed_at);
CREATE INDEX idx_counters_name ON counters(name);
CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_cvs_user_id ON cvs(user_id);
CREATE INDEX idx_analysis_cv_id ON analysis(cv_id);
CREATE INDEX idx_analysis_results_analysis_id ON analysis_results(analysis_id);
CREATE INDEX idx_analysis_results_category_id ON analysis_results(category_id);
