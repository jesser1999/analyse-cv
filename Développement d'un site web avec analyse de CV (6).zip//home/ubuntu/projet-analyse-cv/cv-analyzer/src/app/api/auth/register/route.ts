import { NextRequest, NextResponse } from "next/server";
import { hash } from "bcrypt";
import { D1Database } from "@cloudflare/workers-types";

export async function POST(request: NextRequest) {
  try {
    const { name, email, password } = await request.json();

    // Validation des données
    if (!name || !email || !password) {
      return NextResponse.json(
        { message: "Tous les champs sont requis" },
        { status: 400 }
      );
    }

    if (password.length < 8) {
      return NextResponse.json(
        { message: "Le mot de passe doit contenir au moins 8 caractères" },
        { status: 400 }
      );
    }

    // @ts-ignore - DB sera disponible dans le contexte de l'API
    const db: D1Database = request.env?.DB;

    if (!db) {
      return NextResponse.json(
        { message: "Erreur de connexion à la base de données" },
        { status: 500 }
      );
    }

    // Vérifier si l'utilisateur existe déjà
    const existingUser = await db
      .prepare("SELECT id FROM users WHERE email = ?")
      .bind(email)
      .first();

    if (existingUser) {
      return NextResponse.json(
        { message: "Cet email est déjà utilisé" },
        { status: 409 }
      );
    }

    // Hacher le mot de passe
    const hashedPassword = await hash(password, 10);

    // Insérer le nouvel utilisateur
    const result = await db
      .prepare(
        "INSERT INTO users (email, password_hash, name) VALUES (?, ?, ?) RETURNING id"
      )
      .bind(email, hashedPassword, name)
      .first();

    return NextResponse.json(
      {
        message: "Inscription réussie",
        user: {
          id: result.id,
          email,
          name,
        },
      },
      { status: 201 }
    );
  } catch (error) {
    console.error("Erreur d'inscription:", error);
    return NextResponse.json(
      { message: "Une erreur est survenue lors de l'inscription" },
      { status: 500 }
    );
  }
}
