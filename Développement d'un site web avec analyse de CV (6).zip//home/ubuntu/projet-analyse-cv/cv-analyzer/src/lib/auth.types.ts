import { NextAuthOptions } from "next-auth";
import { D1Database } from "@cloudflare/workers-types";

// Déclaration pour étendre les types de session NextAuth
declare module "next-auth" {
  interface User {
    id: string;
    name: string;
    email: string;
  }

  interface Session {
    user: {
      id: string;
      name: string;
      email: string;
    };
  }
}

// Déclaration pour étendre les types JWT
declare module "next-auth/jwt" {
  interface JWT {
    id: string;
  }
}

// Type pour le contexte d'authentification
export interface AuthContext {
  DB: D1Database;
}
