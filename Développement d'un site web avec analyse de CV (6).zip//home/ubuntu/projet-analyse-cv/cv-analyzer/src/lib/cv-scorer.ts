// Classe pour la notation et la classification des CV
export class CVScorer {
  // Poids des différentes catégories (définis dans l'analyse des exigences)
  private static readonly CATEGORY_WEIGHTS = {
    education: 0.20, // Formation et éducation: 20%
    experience: 0.30, // Expérience professionnelle: 30%
    skills: 0.25, // Compétences techniques: 25%
    languages: 0.10, // Langues: 10%
    projects: 0.15, // Projets personnels et contributions: 15%
  };

  // Fonction principale pour calculer le score global d'un CV
  static calculateScore(analysis: any): { 
    totalScore: number; 
    categoryScores: { [key: string]: { score: number; weight: number; } };
    classification: string;
  } {
    // Calculer le score pour chaque catégorie
    const educationScore = this.evaluateEducation(analysis.education);
    const experienceScore = this.evaluateExperience(analysis.experience);
    const skillsScore = this.evaluateSkills(analysis.skills);
    const languagesScore = this.evaluateLanguages(analysis.languages);
    const projectsScore = this.evaluateProjects(analysis.projects);
    
    // Calculer le score pondéré pour chaque catégorie
    const weightedEducationScore = educationScore * this.CATEGORY_WEIGHTS.education;
    const weightedExperienceScore = experienceScore * this.CATEGORY_WEIGHTS.experience;
    const weightedSkillsScore = skillsScore * this.CATEGORY_WEIGHTS.skills;
    const weightedLanguagesScore = languagesScore * this.CATEGORY_WEIGHTS.languages;
    const weightedProjectsScore = projectsScore * this.CATEGORY_WEIGHTS.projects;
    
    // Calculer le score total (sur 100)
    const totalScore = Math.round(
      weightedEducationScore + 
      weightedExperienceScore + 
      weightedSkillsScore + 
      weightedLanguagesScore + 
      weightedProjectsScore
    );
    
    // Déterminer la classification selon l'échelle internationale
    const classification = this.getClassification(totalScore);
    
    // Retourner les résultats
    return {
      totalScore,
      categoryScores: {
        education: { score: educationScore, weight: this.CATEGORY_WEIGHTS.education },
        experience: { score: experienceScore, weight: this.CATEGORY_WEIGHTS.experience },
        skills: { score: skillsScore, weight: this.CATEGORY_WEIGHTS.skills },
        languages: { score: languagesScore, weight: this.CATEGORY_WEIGHTS.languages },
        projects: { score: projectsScore, weight: this.CATEGORY_WEIGHTS.projects },
      },
      classification
    };
  }
  
  // Évaluation de la formation et éducation (score sur 100)
  private static evaluateEducation(education: any[]): number {
    if (!education || education.length === 0) {
      return 0;
    }
    
    let score = 0;
    
    // Points pour le nombre de formations (max 20 points)
    const formationCount = Math.min(education.length, 4);
    score += formationCount * 5;
    
    // Points pour les diplômes (max 50 points)
    for (const edu of education) {
      const degree = edu.degree.toLowerCase();
      
      if (degree.includes("doctorat") || degree.includes("phd")) {
        score += 50;
        break;
      } else if (degree.includes("master") || degree.includes("mba")) {
        score += 40;
        break;
      } else if (degree.includes("ingénieur")) {
        score += 40;
        break;
      } else if (degree.includes("licence") || degree.includes("bachelor")) {
        score += 30;
        break;
      } else if (degree.includes("bac") || degree.includes("baccalauréat")) {
        score += 20;
        break;
      } else if (degree.includes("certification") || degree.includes("certificat")) {
        score += 10;
      }
    }
    
    // Points pour la présence d'institutions reconnues (max 20 points)
    for (const edu of education) {
      if (edu.institution && edu.institution.length > 0) {
        score += 5;
      }
    }
    
    // Points pour la présence de périodes (max 10 points)
    for (const edu of education) {
      if (edu.period && edu.period.length > 0) {
        score += 2.5;
      }
    }
    
    // Limiter le score à 100
    return Math.min(score, 100);
  }
  
  // Évaluation de l'expérience professionnelle (score sur 100)
  private static evaluateExperience(experience: any[]): number {
    if (!experience || experience.length === 0) {
      return 0;
    }
    
    let score = 0;
    
    // Points pour le nombre d'expériences (max 20 points)
    const experienceCount = Math.min(experience.length, 5);
    score += experienceCount * 4;
    
    // Points pour les titres de poste (max 30 points)
    for (const exp of experience) {
      if (exp.title && exp.title.length > 0) {
        const title = exp.title.toLowerCase();
        
        if (title.includes("directeur") || title.includes("chef") || title.includes("manager")) {
          score += 10;
        } else if (title.includes("ingénieur") || title.includes("développeur") || title.includes("consultant")) {
          score += 8;
        } else if (title.includes("analyste") || title.includes("technicien")) {
          score += 6;
        } else {
          score += 4;
        }
      }
    }
    
    // Points pour les entreprises (max 20 points)
    for (const exp of experience) {
      if (exp.company && exp.company.length > 0) {
        score += 5;
      }
    }
    
    // Points pour les périodes (max 15 points)
    for (const exp of experience) {
      if (exp.period && exp.period.length > 0) {
        score += 3;
      }
    }
    
    // Points pour les descriptions (max 15 points)
    for (const exp of experience) {
      if (exp.description && exp.description.length > 100) {
        score += 3;
      }
    }
    
    // Limiter le score à 100
    return Math.min(score, 100);
  }
  
  // Évaluation des compétences techniques (score sur 100)
  private static evaluateSkills(skills: string[]): number {
    if (!skills || skills.length === 0) {
      return 0;
    }
    
    let score = 0;
    
    // Points pour le nombre de compétences (max 80 points)
    // Chaque compétence vaut 5 points, jusqu'à un maximum de 16 compétences
    const skillCount = Math.min(skills.length, 16);
    score += skillCount * 5;
    
    // Points bonus pour la diversité des compétences (max 20 points)
    // Catégories: langages, frameworks, bases de données, outils, méthodologies
    const categories = {
      languages: ["javascript", "python", "java", "c++", "c#", "php", "ruby", "swift", "kotlin", "go", "typescript"],
      frameworks: ["react", "angular", "vue", "node", "express", "django", "flask", "spring", "laravel", "symfony", "rails"],
      databases: ["mysql", "postgresql", "mongodb", "sqlite", "oracle", "sql server", "firebase", "dynamodb", "cassandra", "redis"],
      tools: ["git", "docker", "kubernetes", "jenkins", "aws", "azure", "gcp", "heroku", "terraform", "ansible"],
      methodologies: ["agile", "scrum", "kanban", "waterfall", "lean", "tdd", "bdd", "ci/cd", "devops"]
    };
    
    const foundCategories = new Set<string>();
    
    for (const skill of skills) {
      for (const [category, categorySkills] of Object.entries(categories)) {
        if (categorySkills.some(s => skill.toLowerCase().includes(s))) {
          foundCategories.add(category);
          break;
        }
      }
    }
    
    // 4 points par catégorie trouvée
    score += foundCategories.size * 4;
    
    // Limiter le score à 100
    return Math.min(score, 100);
  }
  
  // Évaluation des langues (score sur 100)
  private static evaluateLanguages(languages: any[]): number {
    if (!languages || languages.length === 0) {
      return 0;
    }
    
    let score = 0;
    
    // Points pour le nombre de langues (max 60 points)
    // Chaque langue vaut 20 points, jusqu'à un maximum de 3 langues
    const languageCount = Math.min(languages.length, 3);
    score += languageCount * 20;
    
    // Points pour les niveaux de compétence (max 40 points)
    for (const lang of languages) {
      if (lang.level) {
        const level = lang.level.toLowerCase();
        
        if (level.includes("bilingue") || level.includes("natif") || level.includes("c2")) {
          score += 15;
        } else if (level.includes("courant") || level.includes("avancé") || level.includes("c1") || level.includes("b2")) {
          score += 10;
        } else if (level.includes("intermédiaire") || level.includes("b1") || level.includes("a2")) {
          score += 5;
        } else if (level.includes("débutant") || level.includes("a1")) {
          score += 2;
        }
      }
    }
    
    // Limiter le score à 100
    return Math.min(score, 100);
  }
  
  // Évaluation des projets personnels et contributions (score sur 100)
  private static evaluateProjects(projects: any[]): number {
    if (!projects || projects.length === 0) {
      return 0;
    }
    
    let score = 0;
    
    // Points pour le nombre de projets (max 60 points)
    // Chaque projet vaut 15 points, jusqu'à un maximum de 4 projets
    const projectCount = Math.min(projects.length, 4);
    score += projectCount * 15;
    
    // Points pour les URLs (max 20 points)
    for (const project of projects) {
      if (project.url && project.url.length > 0) {
        score += 5;
      }
    }
    
    // Points pour les périodes (max 10 points)
    for (const project of projects) {
      if (project.period && project.period.length > 0) {
        score += 2.5;
      }
    }
    
    // Points pour les descriptions (max 10 points)
    for (const project of projects) {
      if (project.description && project.description.length > 100) {
        score += 2.5;
      }
    }
    
    // Limiter le score à 100
    return Math.min(score, 100);
  }
  
  // Déterminer la classification selon l'échelle internationale
  private static getClassification(score: number): string {
    if (score >= 81) {
      return "Excellent";
    } else if (score >= 61) {
      return "Bon";
    } else if (score >= 41) {
      return "Moyen";
    } else if (score >= 21) {
      return "Passable";
    } else {
      return "Insuffisant";
    }
  }
}
