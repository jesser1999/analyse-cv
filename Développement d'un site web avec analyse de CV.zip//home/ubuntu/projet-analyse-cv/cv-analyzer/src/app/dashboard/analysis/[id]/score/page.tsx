"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";

interface ScoringResult {
  totalScore: number;
  categoryScores: {
    [key: string]: {
      score: number;
      weight: number;
    };
  };
  classification: string;
}

export default function ScorePage({
  params,
}: {
  params: { id: string };
}) {
  const router = useRouter();
  const [scoring, setScoring] = useState<ScoringResult | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    const fetchScoring = async () => {
      try {
        setLoading(true);
        const response = await fetch(`/api/cv/score/${params.id}`);

        if (!response.ok) {
          throw new Error("Erreur lors de la notation du CV");
        }

        const data = await response.json();
        setScoring(data.scoring);
      } catch (error: any) {
        setError(error.message || "Une erreur est survenue");
      } finally {
        setLoading(false);
      }
    };

    fetchScoring();
  }, [params.id]);

  // Fonction pour obtenir la couleur en fonction du score
  const getScoreColor = (score: number) => {
    if (score >= 81) return "text-green-600";
    if (score >= 61) return "text-blue-600";
    if (score >= 41) return "text-yellow-600";
    if (score >= 21) return "text-orange-600";
    return "text-red-600";
  };

  // Fonction pour obtenir la couleur de fond en fonction du score
  const getScoreBackgroundColor = (score: number) => {
    if (score >= 81) return "bg-green-100";
    if (score >= 61) return "bg-blue-100";
    if (score >= 41) return "bg-yellow-100";
    if (score >= 21) return "bg-orange-100";
    return "bg-red-100";
  };

  // Fonction pour obtenir la largeur de la barre de progression
  const getProgressWidth = (score: number) => {
    return `${score}%`;
  };

  if (loading) {
    return (
      <div className="px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex flex-col items-center justify-center py-12">
          <svg
            className="animate-spin h-12 w-12 text-blue-600 mb-4"
            xmlns="http://www.w3.org/2000/svg"
            fill="none"
            viewBox="0 0 24 24"
          >
            <circle
              className="opacity-25"
              cx="12"
              cy="12"
              r="10"
              stroke="currentColor"
              strokeWidth="4"
            ></circle>
            <path
              className="opacity-75"
              fill="currentColor"
              d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
            ></path>
          </svg>
          <h3 className="text-lg font-medium text-gray-900">
            Calcul du score en cours...
          </h3>
          <p className="mt-1 text-sm text-gray-500">
            Veuillez patienter pendant que nous évaluons votre CV.
          </p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="px-4 sm:px-6 lg:px-8 py-8">
        <div className="bg-red-50 border-l-4 border-red-400 p-4 mb-6">
          <div className="flex">
            <div className="flex-shrink-0">
              <svg
                className="h-5 w-5 text-red-400"
                xmlns="http://www.w3.org/2000/svg"
                viewBox="0 0 20 20"
                fill="currentColor"
              >
                <path
                  fillRule="evenodd"
                  d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z"
                  clipRule="evenodd"
                />
              </svg>
            </div>
            <div className="ml-3">
              <p className="text-sm text-red-700">{error}</p>
            </div>
          </div>
        </div>
        <div className="flex justify-center">
          <Link
            href={`/dashboard/analysis/${params.id}`}
            className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
          >
            Retour à l'analyse
          </Link>
        </div>
      </div>
    );
  }

  if (!scoring) {
    return (
      <div className="px-4 sm:px-6 lg:px-8 py-8">
        <div className="bg-yellow-50 border-l-4 border-yellow-400 p-4 mb-6">
          <div className="flex">
            <div className="flex-shrink-0">
              <svg
                className="h-5 w-5 text-yellow-400"
                xmlns="http://www.w3.org/2000/svg"
                viewBox="0 0 20 20"
                fill="currentColor"
              >
                <path
                  fillRule="evenodd"
                  d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z"
                  clipRule="evenodd"
                />
              </svg>
            </div>
            <div className="ml-3">
              <p className="text-sm text-yellow-700">
                Aucun résultat de notation disponible pour ce CV.
              </p>
            </div>
          </div>
        </div>
        <div className="flex justify-center">
          <Link
            href={`/dashboard/analysis/${params.id}`}
            className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
          >
            Retour à l'analyse
          </Link>
        </div>
      </div>
    );
  }

  // Traduction des catégories
  const categoryTranslations: { [key: string]: string } = {
    education: "Formation et éducation",
    experience: "Expérience professionnelle",
    skills: "Compétences techniques",
    languages: "Langues",
    projects: "Projets personnels",
  };

  return (
    <div className="px-4 sm:px-6 lg:px-8 py-6">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-semibold text-gray-900">
          Évaluation du CV
        </h1>
        <Link
          href={`/dashboard/analysis/${params.id}`}
          className="inline-flex items-center px-4 py-2 border border-gray-300 shadow-sm text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
        >
          Retour à l'analyse
        </Link>
      </div>

      {/* Score global */}
      <div className="bg-white shadow overflow-hidden sm:rounded-lg mb-8">
        <div className="px-4 py-5 sm:p-6 text-center">
          <h3 className="text-lg leading-6 font-medium text-gray-900 mb-4">
            Score global
          </h3>
          <div className="flex justify-center">
            <div className={`text-6xl font-bold ${getScoreColor(scoring.totalScore)}`}>
              {scoring.totalScore}
            </div>
            <div className="text-2xl text-gray-500 self-start mt-2">/100</div>
          </div>
          <div className="mt-4">
            <span className={`inline-flex items-center px-3 py-1 rounded-full text-sm font-medium ${getScoreBackgroundColor(scoring.totalScore)} ${getScoreColor(scoring.totalScore)}`}>
              {scoring.classification}
            </span>
          </div>
          <p className="mt-4 text-sm text-gray-500">
            Basé sur l'échelle internationale de notation des CV
          </p>
        </div>
      </div>

      {/* Scores par catégorie */}
      <div className="bg-white shadow overflow-hidden sm:rounded-lg mb-8">
        <div className="px-4 py-5 sm:px-6">
          <h3 className="text-lg leading-6 font-medium text-gray-900">
            Scores par catégorie
          </h3>
          <p className="mt-1 max-w-2xl text-sm text-gray-500">
            Détail des scores pour chaque catégorie évaluée
          </p>
        </div>
        <div className="border-t border-gray-200">
          <dl>
            {Object.entries(scoring.categoryScores).map(([category, data], index) => (
              <div key={category} className={`${index % 2 === 0 ? 'bg-gray-50' : 'bg-white'} px-4 py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6`}>
                <dt className="text-sm font-medium text-gray-500">
                  {categoryTranslations[category] || category}
                  <span className="block text-xs text-gray-400 mt-1">
                    Pondération: {Math.round(data.weight * 100)}%
                  </span>
                </dt>
                <dd className="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">
                  <div className="flex items-center">
                    <div className="w-full bg-gray-200 rounded-full h-2.5 mr-4">
                      <div 
                        className={`h-2.5 rounded-full ${getScoreBackgroundColor(data.score)}`} 
                        style={{ width: getProgressWidth(data.score) }}
                      ></div>
                    </div>
                    <span className={`text-sm font-medium ${getScoreColor(data.score)}`}>
                      {data.score}/100
                    </span>
                  </div>
                </dd>
              </div>
            ))}
          </dl>
        </div>
      </div>

      {/* Échelle de notation */}
      <div className="bg-white shadow overflow-hidden sm:rounded-lg">
        <div className="px-4 py-5 sm:px-6">
          <h3 className="text-lg leading-6 font-medium text-gray-900">
            Échelle de notation internationale
          </h3>
          <p className="mt-1 max-w-2xl text-sm text-gray-500">
            Référence pour l'interprétation des scores
          </p>
        </div>
        <div className="border-t border-gray-200">
          <dl>
            <div className="bg-gray-50 px-4 py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
              <dt className="text-sm font-medium text-gray-500">81-100</dt>
              <dd className="mt-1 text-sm text-green-600 font-medium sm:mt-0 sm:col-span-2">
                Excellent
              </dd>
            </div>
            <div className="bg-white px-4 py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
              <dt className="text-sm font-medium text-gray-500">61-80</dt>
              <dd className="mt-1 text-sm text-blue-600 font-medium sm:mt-0 sm:col-span-2">
                Bon
              </dd>
            </div>
            <div className="bg-gray-50 px-4 py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
              <dt className="text-sm font-medium text-gray-500">41-60</dt>
              <dd className="mt-1 text-sm text-yellow-600 font-medium sm:mt-0 sm:col-span-2">
                Moyen
              </dd>
            </div>
            <div className="bg-white px-4 py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
              <dt className="text-sm font-medium text-gray-500">21-40</dt>
              <dd className="mt-1 text-sm text-orange-600 font-medium sm:mt-0 sm:col-span-2">
                Passable
              </dd>
            </div>
            <div className="bg-gray-50 px-4 py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
              <dt className="text-sm font-medium text-gray-500">0-20</dt>
              <dd className="mt-1 text-sm text-red-600 font-medium sm:mt-0 sm:col-span-2">
                Insuffisant
              </dd>
            </div>
          </dl>
        </div>
      </div>
    </div>
  );
}
