import NextAuth from "next-auth";
import CredentialsProvider from "next-auth/providers/credentials";
import GoogleProvider from "next-auth/providers/google";
import GitHubProvider from "next-auth/providers/github";
import { D1Database } from "@cloudflare/workers-types";
import { compare } from "bcrypt";

// Fonction pour vérifier les identifiants de l'utilisateur
async function verifyCredentials(
  db: D1Database,
  email: string,
  password: string
) {
  const user = await db
    .prepare("SELECT id, email, password_hash, name FROM users WHERE email = ?")
    .bind(email)
    .first();

  if (!user) {
    return null;
  }

  const isValid = await compare(password, user.password_hash);
  if (!isValid) {
    return null;
  }

  return {
    id: user.id.toString(),
    email: user.email,
    name: user.name,
  };
}

const handler = NextAuth({
  providers: [
    CredentialsProvider({
      name: "Credentials",
      credentials: {
        email: { label: "Email", type: "email" },
        password: { label: "Mot de passe", type: "password" },
      },
      async authorize(credentials) {
        if (!credentials?.email || !credentials?.password) {
          return null;
        }

        try {
          // @ts-ignore - DB sera disponible dans le contexte de l'API
          const db = process.env.DB;
          return await verifyCredentials(
            db,
            credentials.email,
            credentials.password
          );
        } catch (error) {
          console.error("Erreur d'authentification:", error);
          return null;
        }
      },
    }),
    GoogleProvider({
      clientId: process.env.GOOGLE_CLIENT_ID || "",
      clientSecret: process.env.GOOGLE_CLIENT_SECRET || "",
    }),
    GitHubProvider({
      clientId: process.env.GITHUB_CLIENT_ID || "",
      clientSecret: process.env.GITHUB_CLIENT_SECRET || "",
    }),
  ],
  session: {
    strategy: "jwt",
  },
  pages: {
    signIn: "/auth/signin",
    signOut: "/auth/signout",
    error: "/auth/error",
  },
  callbacks: {
    async jwt({ token, user }) {
      if (user) {
        token.id = user.id;
      }
      return token;
    },
    async session({ session, token }) {
      if (session.user) {
        session.user.id = token.id as string;
      }
      return session;
    },
  },
});

export { handler as GET, handler as POST };
