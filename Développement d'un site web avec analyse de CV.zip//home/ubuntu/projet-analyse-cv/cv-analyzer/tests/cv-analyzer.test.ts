import { describe, it, expect, beforeEach, vi } from 'vitest';
import { CVAnalyzer } from '../src/lib/cv-analyzer';

// Mock des fonctions fs et des bibliothèques externes
vi.mock('fs/promises', () => ({
  readFile: vi.fn().mockResolvedValue(Buffer.from('Contenu du CV de test')),
}));

vi.mock('pdf-parse', () => {
  return {
    default: vi.fn().mockResolvedValue({ text: 'Contenu du CV PDF extrait' }),
  };
});

vi.mock('mammoth', () => ({
  extractRawText: vi.fn().mockResolvedValue({ value: 'Contenu du CV DOCX extrait' }),
}));

describe('CVAnalyzer', () => {
  describe('extractText', () => {
    it('devrait extraire le texte d\'un fichier PDF', async () => {
      const text = await CVAnalyzer.extractText('/chemin/vers/cv.pdf', 'application/pdf');
      expect(text).toBe('Contenu du CV PDF extrait');
    });

    it('devrait extraire le texte d\'un fichier DOCX', async () => {
      const text = await CVAnalyzer.extractText('/chemin/vers/cv.docx', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document');
      expect(text).toBe('Contenu du CV DOCX extrait');
    });

    it('devrait rejeter les formats de fichier non supportés', async () => {
      await expect(CVAnalyzer.extractText('/chemin/vers/cv.txt', 'text/plain')).rejects.toThrow('Format de fichier non supporté');
    });
  });

  describe('analyzeCV', () => {
    it('devrait analyser le contenu d\'un CV', () => {
      const cvText = `
        CURRICULUM VITAE
        
        Jean Dupont
        Email: jean.dupont@email.com
        
        FORMATION
        2015-2018 Master en Informatique, Université de Paris
        2012-2015 Licence en Informatique, Université de Lyon
        
        EXPÉRIENCE PROFESSIONNELLE
        2018-2023 Développeur Full Stack, Entreprise XYZ
        - Développement d'applications web avec React et Node.js
        - Gestion de bases de données PostgreSQL
        
        2016-2018 Stage Développeur Frontend, Startup ABC
        - Création d'interfaces utilisateur avec HTML, CSS et JavaScript
        
        COMPÉTENCES
        Langages: JavaScript, Python, Java, HTML, CSS
        Frameworks: React, Node.js, Express, Django
        Bases de données: PostgreSQL, MongoDB
        Outils: Git, Docker, AWS
        
        LANGUES
        Français: Natif
        Anglais: Courant (C1)
        Espagnol: Intermédiaire (B1)
        
        PROJETS PERSONNELS
        2020-2023 Application de gestion de tâches
        - Développement d'une application web avec React et Firebase
        - Code source disponible sur https://github.com/jeandupont/taskmanager
      `;
      
      const analysis = CVAnalyzer.analyzeCV(cvText);
      
      // Vérifier que l'analyse contient toutes les sections attendues
      expect(analysis).toHaveProperty('education');
      expect(analysis).toHaveProperty('experience');
      expect(analysis).toHaveProperty('skills');
      expect(analysis).toHaveProperty('languages');
      expect(analysis).toHaveProperty('projects');
      
      // Vérifier que des compétences ont été détectées
      expect(analysis.skills).toContain('javascript');
      expect(analysis.skills).toContain('react');
      
      // Vérifier que des langues ont été détectées
      expect(analysis.languages.length).toBeGreaterThan(0);
      
      // Vérifier que le texte brut est inclus
      expect(analysis.raw_text).toBe(cvText);
    });
  });
});
