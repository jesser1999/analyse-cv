import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";

// Fonction pour récupérer les CV d'un utilisateur
export async function GET(request: NextRequest) {
  try {
    // Vérifier l'authentification
    // @ts-ignore - La session sera disponible dans le contexte de l'API
    const session = await getServerSession();
    if (!session || !session.user) {
      return NextResponse.json(
        { message: "Non autorisé" },
        { status: 401 }
      );
    }

    // Récupérer l'ID de l'utilisateur
    const userId = session.user.id;
    
    // @ts-ignore - DB sera disponible dans le contexte de l'API
    const db = request.env?.DB;
    
    if (!db) {
      return NextResponse.json(
        { message: "Erreur de connexion à la base de données" },
        { status: 500 }
      );
    }
    
    // Récupérer tous les CV de l'utilisateur
    const cvs = await db
      .prepare(
        "SELECT id, file_name, file_type, upload_date, file_size FROM cvs WHERE user_id = ? ORDER BY upload_date DESC"
      )
      .bind(userId)
      .all();
    
    return NextResponse.json(
      {
        cvs: cvs.results
      },
      { status: 200 }
    );
  } catch (error) {
    console.error("Erreur lors de la récupération des CV:", error);
    return NextResponse.json(
      { message: "Une erreur est survenue lors de la récupération des CV" },
      { status: 500 }
    );
  }
}
