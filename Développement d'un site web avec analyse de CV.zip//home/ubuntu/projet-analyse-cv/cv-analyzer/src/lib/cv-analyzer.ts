import { readFile } from "fs/promises";
import * as pdfParse from "pdf-parse";
import * as mammoth from "mammoth";
import * as natural from "natural";
import * as compromise from "compromise";

// Classe pour l'extraction et l'analyse de texte des CV
export class CVAnalyzer {
  // Fonction pour extraire le texte d'un fichier PDF
  static async extractTextFromPDF(filePath: string): Promise<string> {
    try {
      const dataBuffer = await readFile(filePath);
      const data = await pdfParse(dataBuffer);
      return data.text;
    } catch (error) {
      console.error("Erreur lors de l'extraction du texte du PDF:", error);
      throw new Error("Impossible d'extraire le texte du PDF");
    }
  }

  // Fonction pour extraire le texte d'un fichier DOCX
  static async extractTextFromDOCX(filePath: string): Promise<string> {
    try {
      const dataBuffer = await readFile(filePath);
      const result = await mammoth.extractRawText({ buffer: dataBuffer });
      return result.value;
    } catch (error) {
      console.error("Erreur lors de l'extraction du texte du DOCX:", error);
      throw new Error("Impossible d'extraire le texte du DOCX");
    }
  }

  // Fonction pour extraire le texte d'un CV (PDF ou DOCX)
  static async extractText(filePath: string, fileType: string): Promise<string> {
    if (fileType === "application/pdf") {
      return this.extractTextFromPDF(filePath);
    } else if (
      fileType ===
      "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
    ) {
      return this.extractTextFromDOCX(filePath);
    } else {
      throw new Error("Format de fichier non supporté");
    }
  }

  // Fonction pour analyser le contenu du CV
  static analyzeCV(text: string): any {
    // Tokenisation et normalisation du texte
    const tokenizer = new natural.WordTokenizer();
    const tokens = tokenizer.tokenize(text.toLowerCase());
    
    // Analyse avec compromise pour extraire des entités
    const doc = compromise(text);
    
    // Extraction des sections principales du CV
    const analysis = {
      education: this.extractEducation(text, doc),
      experience: this.extractExperience(text, doc),
      skills: this.extractSkills(text, tokens),
      languages: this.extractLanguages(text, doc),
      projects: this.extractProjects(text, doc),
      raw_text: text
    };
    
    return analysis;
  }
  
  // Extraction de la formation et éducation
  private static extractEducation(text: string, doc: any): any[] {
    const educationKeywords = [
      "diplôme", "formation", "éducation", "université", "école", 
      "baccalauréat", "bac", "master", "doctorat", "licence", "ingénieur",
      "certification", "certificat"
    ];
    
    // Recherche des paragraphes contenant des mots-clés d'éducation
    const educationSections = this.extractSectionsByKeywords(text, educationKeywords);
    
    // Extraction des dates avec compromise
    const dates = doc.dates().out('array');
    
    // Extraction des organisations (écoles, universités)
    const organizations = doc.organizations().out('array');
    
    // Combinaison des informations
    const education = [];
    
    for (const section of educationSections) {
      // Recherche de diplômes dans la section
      const degreeMatch = section.match(/\b(master|doctorat|licence|baccalauréat|bac|ingénieur|certification|certificat)\b/i);
      const degree = degreeMatch ? degreeMatch[0] : "";
      
      // Recherche d'une organisation dans la section
      const org = organizations.find(o => section.includes(o));
      
      // Recherche de dates dans la section
      const sectionDates = dates.filter(d => section.includes(d));
      const period = sectionDates.length > 0 ? sectionDates.join(" - ") : "";
      
      education.push({
        degree,
        institution: org || "",
        period,
        description: section
      });
    }
    
    return education;
  }
  
  // Extraction de l'expérience professionnelle
  private static extractExperience(text: string, doc: any): any[] {
    const experienceKeywords = [
      "expérience", "professionnel", "emploi", "travail", "poste", 
      "fonction", "responsabilité", "mission", "entreprise", "société"
    ];
    
    // Recherche des paragraphes contenant des mots-clés d'expérience
    const experienceSections = this.extractSectionsByKeywords(text, experienceKeywords);
    
    // Extraction des dates avec compromise
    const dates = doc.dates().out('array');
    
    // Extraction des organisations (entreprises)
    const organizations = doc.organizations().out('array');
    
    // Combinaison des informations
    const experiences = [];
    
    for (const section of experienceSections) {
      // Recherche d'un titre de poste dans la section
      const titleMatch = section.match(/\b(développeur|ingénieur|chef|directeur|manager|consultant|analyste|technicien|responsable)\b/i);
      const title = titleMatch ? titleMatch[0] : "";
      
      // Recherche d'une organisation dans la section
      const org = organizations.find(o => section.includes(o));
      
      // Recherche de dates dans la section
      const sectionDates = dates.filter(d => section.includes(d));
      const period = sectionDates.length > 0 ? sectionDates.join(" - ") : "";
      
      experiences.push({
        title,
        company: org || "",
        period,
        description: section
      });
    }
    
    return experiences;
  }
  
  // Extraction des compétences techniques
  private static extractSkills(text: string, tokens: string[]): string[] {
    const technicalSkills = [
      // Langages de programmation
      "javascript", "python", "java", "c++", "c#", "php", "ruby", "swift", "kotlin", "go",
      "typescript", "html", "css", "sql", "nosql", "bash", "powershell", "rust", "scala",
      
      // Frameworks et bibliothèques
      "react", "angular", "vue", "node", "express", "django", "flask", "spring", "laravel",
      "symfony", "rails", "jquery", "bootstrap", "tailwind", "material-ui", "next.js", "nuxt",
      
      // Bases de données
      "mysql", "postgresql", "mongodb", "sqlite", "oracle", "sql server", "firebase", "dynamodb",
      "cassandra", "redis", "elasticsearch", "neo4j",
      
      // DevOps et outils
      "git", "docker", "kubernetes", "jenkins", "travis", "aws", "azure", "gcp", "heroku",
      "terraform", "ansible", "puppet", "chef", "circleci", "gitlab", "github", "bitbucket",
      
      // Méthodologies
      "agile", "scrum", "kanban", "waterfall", "lean", "tdd", "bdd", "ci/cd", "devops",
      
      // Autres compétences techniques
      "machine learning", "deep learning", "ai", "data science", "big data", "blockchain",
      "iot", "cloud", "microservices", "rest", "graphql", "websocket", "oauth", "jwt"
    ];
    
    // Recherche des compétences techniques dans les tokens
    const skills = new Set<string>();
    
    for (const token of tokens) {
      if (technicalSkills.includes(token)) {
        skills.add(token);
      }
    }
    
    // Recherche de compétences composées de plusieurs mots
    for (const skill of technicalSkills) {
      if (skill.includes(" ") && text.toLowerCase().includes(skill)) {
        skills.add(skill);
      }
    }
    
    return Array.from(skills);
  }
  
  // Extraction des langues
  private static extractLanguages(text: string, doc: any): any[] {
    const languageKeywords = [
      "langue", "langues", "linguistique", "parler", "écrit", "oral",
      "français", "anglais", "espagnol", "allemand", "italien", "portugais",
      "russe", "chinois", "japonais", "arabe", "néerlandais", "suédois"
    ];
    
    // Recherche des paragraphes contenant des mots-clés de langues
    const languageSections = this.extractSectionsByKeywords(text, languageKeywords);
    
    // Liste des langues courantes
    const commonLanguages = [
      "français", "anglais", "espagnol", "allemand", "italien", "portugais",
      "russe", "chinois", "japonais", "arabe", "néerlandais", "suédois"
    ];
    
    // Liste des niveaux de compétence
    const levels = [
      "débutant", "intermédiaire", "avancé", "courant", "bilingue", "natif",
      "a1", "a2", "b1", "b2", "c1", "c2"
    ];
    
    // Extraction des langues et niveaux
    const languages = [];
    
    for (const section of languageSections) {
      for (const language of commonLanguages) {
        if (section.toLowerCase().includes(language)) {
          // Recherche du niveau pour cette langue
          let level = "";
          for (const l of levels) {
            if (section.toLowerCase().includes(l)) {
              level = l;
              break;
            }
          }
          
          languages.push({
            language,
            level
          });
        }
      }
    }
    
    return languages;
  }
  
  // Extraction des projets personnels et contributions
  private static extractProjects(text: string, doc: any): any[] {
    const projectKeywords = [
      "projet", "projets", "personnel", "github", "gitlab", "open source",
      "contribution", "développement", "réalisation", "création"
    ];
    
    // Recherche des paragraphes contenant des mots-clés de projets
    const projectSections = this.extractSectionsByKeywords(text, projectKeywords);
    
    // Extraction des dates avec compromise
    const dates = doc.dates().out('array');
    
    // Extraction des URLs
    const urlRegex = /(https?:\/\/[^\s]+)/g;
    const urls = text.match(urlRegex) || [];
    
    // Combinaison des informations
    const projects = [];
    
    for (const section of projectSections) {
      // Recherche d'un nom de projet dans la section
      const nameMatch = section.match(/\b([A-Z][a-z]+(?:\s[A-Z][a-z]+)*)\b/);
      const name = nameMatch ? nameMatch[0] : "Projet";
      
      // Recherche d'URLs dans la section
      const sectionUrls = urls.filter(url => section.includes(url));
      const url = sectionUrls.length > 0 ? sectionUrls[0] : "";
      
      // Recherche de dates dans la section
      const sectionDates = dates.filter(d => section.includes(d));
      const period = sectionDates.length > 0 ? sectionDates.join(" - ") : "";
      
      projects.push({
        name,
        url,
        period,
        description: section
      });
    }
    
    return projects;
  }
  
  // Fonction utilitaire pour extraire des sections de texte basées sur des mots-clés
  private static extractSectionsByKeywords(text: string, keywords: string[]): string[] {
    // Diviser le texte en paragraphes
    const paragraphs = text.split(/\n\s*\n/);
    
    // Filtrer les paragraphes contenant au moins un mot-clé
    return paragraphs.filter(paragraph => {
      const lowerParagraph = paragraph.toLowerCase();
      return keywords.some(keyword => lowerParagraph.includes(keyword.toLowerCase()));
    });
  }
}
